package prog3_3;

import java.util.Arrays;

public class MyStringList {
	private final int INITIAL_LENGTH = 2;
	private String[] strArray; 
	private int size;
	
	public MyStringList() {
		strArray = new String[INITIAL_LENGTH];
		size = 0;
	}
	
	public void add(String s){
		if(this.strArray.length==size) resize();
		this.strArray[size]=s;
		this.size++;
	}
	
	public String get(int i){
		if(i>strArray.length) return null;
		return strArray[i];
	}
	
	public boolean find(String s){
		for(int i=0; i<strArray.length; i++) {
			if(strArray[i]!=null && strArray[i].equalsIgnoreCase(s)) return true;
		}
		return false;
	}
	
	public void insert(String s, int pos){
		if(pos>size) pos=size;
		if(this.strArray.length<(size+1)) resize();
		
		String[] temp=new String[strArray.length];
		int counter=0;
		for(int i=0;i<strArray.length;i++) {
			
			if(i==pos) {
				temp[i]=s;
				counter++;
			}else if(i!=strArray.length) {
				temp[i]=strArray[i-counter];
			}
		}
		
		strArray=temp;
		size++;
	}
	
	public boolean remove(String s){
		String[] temp=new String[strArray.length]; 
		
		if(!find(s)) {
			return false;
		}
		
		int counter=0;
		for(int i=0; i<strArray.length;i++) {
			if(!s.equalsIgnoreCase(strArray[i])) { 
				temp[counter]=strArray[i];
				counter++;
			}
		}
		this.strArray=temp;
		this.size--;
		
		
		return true;
	}
	
	
	private void resize(){
		int current= this.strArray.length;
		String[] temp=this.strArray;
		
		this.strArray= new String[INITIAL_LENGTH+current];
		
		for(int i=0;i<temp.length; i++) {
			this.strArray[i]=temp[i];
		}
		System.out.println("Resizing.....");
	}
	public String toString(){
		int counter=0;
		
		for(String data:strArray) {
			if(data!=null) counter++;
		}
		String[] result =new String[counter];
		for(int i=0;i<counter; i++) {
			result[i]=strArray[i];
		}
		return Arrays.toString(result);
	}
	public int size() {
		return size;
	}

	public static void main(String[] args){
//		MyStringList l = new MyStringList();
//		l.add("Bob");
//		l.add("Steve");
//		l.add("Susan");
//		l.add("Mark");
//		l.add("Dave");
//		System.out.println("The list of size "+l.size()+" is "+l);
//		l.remove("Mark");
//		l.remove("Bob");
//		System.out.println("The list of size "+l.size()+" is "+l);
//		l.insert("Richard",3);
//		System.out.println("The list of size "+l.size()+" after inserting Richard into pos 3 is "+l);
//		l.insert("Tonya",0);
//		System.out.println("The list of size "+l.size()+" after inserting Tonya into pos 0 is "+l);	
		
		MyStringList l = new MyStringList();
		l.add("Bob");
		System.out.println("The list of size " + l.size() + " is " + l);
		l.add("Steve");
		System.out.println("The list of size " + l.size() + " is " + l);
		l.add("Susan");
		System.out.println("The list of size " + l.size() + " is " + l);
		l.add("Mark");
		System.out.println("The list of size " + l.size() + " is " + l);
		l.add("Dave");
		System.out.println("The list of size " + l.size() + " is " + l);
		l.remove("Mark");
		System.out.println("The list of size " + l.size() + " is " + l);
		l.remove("Bob");
		System.out.println("The list of size " + l.size() + " is " + l);
		
		
		System.out.println("------------------------------------------------------");
		System.out.println("The index 2 data:"+l.get(2));
		
		l.insert("AAA", 0);
		System.out.println("Insert index 0! The list of size " + l.size() + " is " + l);
		
		l.insert("BBB", 5);
		System.out.println("Insert index 5! The list of size " + l.size() + " is " + l);
		
		l.insert("CCC", 3);
		System.out.println("Insert index 3! The list of size " + l.size() + " is " + l);
		
		l.remove("Bob");
		l.remove("CCC");
		System.out.println("The list of size " + l.size() + " is " + l);
		
	}

}
