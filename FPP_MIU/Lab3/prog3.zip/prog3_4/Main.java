package prog3_4;

public class Main {

	public static void main(String[] args) {
		
		Triangle triangle = new Triangle(7, 10);
		Rectangle rectangle = new Rectangle(6, 6);
		Circle circle = new Circle(4);
		
		System.out.println("Area of Triangle = " + triangle.computeArea());
		System.out.println("Area of Rectangle = " + rectangle.computeArea());
		System.out.println("Area of Circle = " + circle.computeArea());
			
	}

}
