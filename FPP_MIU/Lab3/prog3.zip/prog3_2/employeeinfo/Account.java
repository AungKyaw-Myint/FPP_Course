package prog3_2.employeeinfo;

 class Account {
	private final static double DEFAULT_BALANCE = 0.0;
	private double balance;
	private String employee;

	Account(String emp, double balance) {
		employee = emp;
		this.balance = balance;
	}

	Account(String emp) {
		this(emp, DEFAULT_BALANCE);
	}

	public String toString() {
		return "type = " +  ", balance = " + balance;
	}

	public void makeDeposit(double deposit) {
		if(deposit>0) {
			this.balance+=deposit;
		}
	}

	public boolean makeWithdrawal(String name, String accType,double amount) {
		if(amount<0 || amount> this.balance) {
			System.out.println(name+" withdrawing " +accType+" insufficient of :"+ amount);
			return false;
		}
		
		this.balance= this.balance-amount;
		System.out.println(name+" withdraw of "+accType+" :"+ amount);
		return true;
	}

	public double getBalance() {
		return balance;
	}
}
