package prog3_2.employeeinfo;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Employee {
	private Account savingsAcct;
	private Account checkingAcct;
	private Account retirementAcct;
	private String name;
	private LocalDate hireDate;
	
	public Employee(String name, int yearOfHire, int monthOfHire, int dayOfHire){
		this.name = name;
/* update, using LocalDate
		GregorianCalendar cal = new GregorianCalendar(yearOfHire,monthOfHire-1,dayOfHire);
		hireDate = cal.getTime();
*/
		GregorianCalendar cal = new GregorianCalendar(yearOfHire, monthOfHire - 1, dayOfHire);
		
		hireDate = LocalDate.of(cal.get(Calendar.YEAR), 1 + cal.get(Calendar.MONTH),
				cal.get(Calendar.DATE));
	}

	
	public void createNewChecking(double startAmount) {
		// implement
		
		this.checkingAcct=new Account(this.name, startAmount);
		
	}

	public void createNewSavings(double startAmount) {
		// implement
		this.savingsAcct=new Account(this.name, startAmount);
		
	}

	public void createNewRetirement(double startAmount) {
		// implement
		this.retirementAcct=new Account(this.name, startAmount);
	}

	public String getFormattedAcctInfo() {
		// implement
		
		String result=null;
		
		result= String.format("ACCOUNT INFO FOR %s: %n %n",this.name);
		
		if(this.checkingAcct !=null) {
			result+= String.format("Account type: %s %n","checking");
			result+= String.format("Current bal: %8.2f %n",this.checkingAcct.getBalance());
		}
		
		if(this.savingsAcct !=null) {
			result+= String.format("Account type: %s %n","savings");
			result+= String.format("Account type: %8.2f %n",this.savingsAcct.getBalance());
		}
		
		if(this.retirementAcct !=null) {
			result+= String.format("Account type: %s %n","retirement");
			result+= String.format("Account type: %8.2f %n",this.retirementAcct.getBalance());
		}
		result+= String.format("%n");
		return result;
	}
	public void deposit(String acctType, double amt){
		// implement
		if(acctType.contains("saving")) {
			savingsAcct.makeDeposit(amt);
			System.out.println(this.name+" deposit of saving:"+amt);
		}else if(acctType.contains("checking")) {
			checkingAcct.makeDeposit(amt);
			System.out.println(this.name+" deposit of checking:"+amt);
		}else if(acctType.contains("retire")) {
			retirementAcct.makeDeposit(amt);
			System.out.println(this.name+" deposit of retire:"+amt);
		}
		
	}
	public boolean withdraw(String acctType, double amt){
		
		if(acctType.contains("saving")) {
			return savingsAcct.makeWithdrawal(this.name,"saving",amt);
		}else if(acctType.contains("checking")) {
			return checkingAcct.makeWithdrawal(this.name,"checking",amt);
		}else if(acctType.contains("retire")) {
			return retirementAcct.makeWithdrawal(this.name,"retire",amt);
		}
		
		return false;
	}


	public String getName() {
		return name;
	}


	public LocalDate getHireDate() {
		return hireDate;
	}

//
//	@Override
//	public String toString() {
//		return "Employee [savingsAcct=" + savingsAcct + ", checkingAcct=" + checkingAcct + ", retirementAcct="
//				+ retirementAcct + ", name=" + name + ", hireDate=" + hireDate + "]";
//	}

}
