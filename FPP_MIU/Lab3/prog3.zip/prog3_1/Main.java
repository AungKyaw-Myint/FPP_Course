package prog3_1;

public class Main {

	public static void main(String[] args) {
		Employee employee=new Employee("AungKyawMyint", "Aung", 120000.00, 2024, 1, 1);
		Account checkingAcc=new Account(employee, AccountType.CHECKING, 300);
		Account savingAcc=new Account(employee, AccountType.SAVINGS, 300);
		Account retireAcc=new Account(employee, AccountType.RETIREMENT, 300);
		
		
		checkingAcc.makeDeposit(500);
		savingAcc.makeWithdrawal(200);
		savingAcc.makeWithdrawal(200);
		
		System.out.println("Checking Acc:"+checkingAcc.toString());
		System.out.println("Saving Acc:"+savingAcc.toString());
		System.out.println("Retire Acc:"+retireAcc.toString());

	}

}
