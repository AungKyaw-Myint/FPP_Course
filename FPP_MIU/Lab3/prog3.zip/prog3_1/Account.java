package prog3_1;

 class Account {
	private final static double DEFAULT_BALANCE = 0.0;
	private double balance;
	private AccountType acctType;
	private Employee employee;

	Account(Employee emp, AccountType acctType, double balance) {
		employee = emp;
		this.acctType = acctType;
		this.balance = balance;
	}

	Account(Employee emp, AccountType acctType) {
		this(emp, acctType, DEFAULT_BALANCE);
	}

	public String toString() {
		return "type = " + acctType + ", balance = " + balance;
	}

	public void makeDeposit(double deposit) {
		if(deposit>0) {
			this.balance+=deposit;
			System.out.println("Deposit of "+this.acctType+" :"+deposit);
		}
	}

	public boolean makeWithdrawal(double amount) {
		if(amount<0 || amount> this.balance) {
			System.out.println("Withdrawing insufficient of "+this.acctType+" :"+ amount);
			return false;
		}
		
		this.balance= this.balance-amount;
		System.out.println("Withdraw of "+this.acctType+" :"+ amount);
		return true;
	}

	public double getBalance() {
		return balance;
	}

	public AccountType getAcctType() {
		return acctType;
	}
}
