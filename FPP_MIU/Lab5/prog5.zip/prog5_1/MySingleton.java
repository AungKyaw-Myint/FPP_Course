package prog5_1;

public class MySingleton {
	
	private static int count=0;
	private static MySingleton instance;
	
	private MySingleton() {
		count++;
	}
	
	public static MySingleton getInstance() {
		if(instance == null) {
			instance = new MySingleton();
		}
		return instance;
	}

	public static void main(String[] args) {
		for(int i = 0; i < 10; ++i) {
			MySingleton.getInstance();
		}
		System.out.println(count);

	}

	
//	1. How do you prevent users of your class from creating multiple instances? 
//	-All private declaration except static method.
//		Why can't they just invoke the constructor of your class multiple times? 
//	-Condition with instance
//	2. If two clients attempt to access an instance of your class, how can you guarantee they will
//	get the same instance?		
//	-That should be static level and can't changeable.
//	3. How can you test your class to prove that it really is a Singleton? 
//	-Calling multiple time.
}
